﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMatricula = new Label();
            lblNome = new Label();
            lblSalMen = new Label();
            lblEntra = new Label();
            tbxMat = new TextBox();
            tbxNome = new TextBox();
            tbxSalMen = new TextBox();
            tbxEntrada = new TextBox();
            btnInsMen = new Button();
            btnInstParamet = new Button();
            SuspendLayout();
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(128, 66);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(71, 20);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(128, 99);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(50, 20);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // lblSalMen
            // 
            lblSalMen.AutoSize = true;
            lblSalMen.Location = new Point(128, 133);
            lblSalMen.Name = "lblSalMen";
            lblSalMen.Size = new Size(106, 20);
            lblSalMen.TabIndex = 2;
            lblSalMen.Text = "Salário Mensal";
            // 
            // lblEntra
            // 
            lblEntra.AutoSize = true;
            lblEntra.Location = new Point(128, 166);
            lblEntra.Name = "lblEntra";
            lblEntra.Size = new Size(141, 20);
            lblEntra.TabIndex = 3;
            lblEntra.Text = "Entrada na Empresa";
            // 
            // tbxMat
            // 
            tbxMat.Location = new Point(298, 66);
            tbxMat.Name = "tbxMat";
            tbxMat.Size = new Size(125, 27);
            tbxMat.TabIndex = 4;
            // 
            // tbxNome
            // 
            tbxNome.Location = new Point(298, 99);
            tbxNome.Name = "tbxNome";
            tbxNome.Size = new Size(125, 27);
            tbxNome.TabIndex = 5;
            // 
            // tbxSalMen
            // 
            tbxSalMen.Location = new Point(298, 133);
            tbxSalMen.Name = "tbxSalMen";
            tbxSalMen.Size = new Size(125, 27);
            tbxSalMen.TabIndex = 6;
            // 
            // tbxEntrada
            // 
            tbxEntrada.Location = new Point(298, 166);
            tbxEntrada.Name = "tbxEntrada";
            tbxEntrada.Size = new Size(125, 27);
            tbxEntrada.TabIndex = 7;
            // 
            // btnInsMen
            // 
            btnInsMen.Location = new Point(193, 283);
            btnInsMen.Name = "btnInsMen";
            btnInsMen.Size = new Size(133, 88);
            btnInsMen.TabIndex = 8;
            btnInsMen.Text = "Instanciar Mensalista";
            btnInsMen.UseVisualStyleBackColor = true;
            btnInsMen.Click += btnInsMen_Click;
            // 
            // btnInstParamet
            // 
            btnInstParamet.Location = new Point(446, 283);
            btnInstParamet.Name = "btnInstParamet";
            btnInstParamet.Size = new Size(121, 88);
            btnInstParamet.TabIndex = 9;
            btnInstParamet.Text = "Instanciação com passagem de parametros";
            btnInstParamet.UseVisualStyleBackColor = true;
            btnInstParamet.Click += btnInstParamet_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInstParamet);
            Controls.Add(btnInsMen);
            Controls.Add(tbxEntrada);
            Controls.Add(tbxSalMen);
            Controls.Add(tbxNome);
            Controls.Add(tbxMat);
            Controls.Add(lblEntra);
            Controls.Add(lblSalMen);
            Controls.Add(lblNome);
            Controls.Add(lblMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMatricula;
        private Label lblNome;
        private Label lblSalMen;
        private Label lblEntra;
        private TextBox tbxMat;
        private TextBox tbxNome;
        private TextBox tbxSalMen;
        private TextBox tbxEntrada;
        private Button btnInsMen;
        private Button btnInstParamet;
    }
}