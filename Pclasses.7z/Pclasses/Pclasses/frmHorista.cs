﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInsMen_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista();

            horista.NomeEmpregado = tbxNome.Text;
            horista.Matricula = Convert.ToInt32(tbxMat.Text);
            horista.SalarioHora = Convert.ToDouble(tbxSal.Text);
            horista.NumeroHora = Convert.ToDouble(tbxHora.Text);
            horista.DataEntradaEmpresa = Convert.ToDateTime(tbxDataEntrada.Text);
            horista.DiasFalta = Convert.ToInt32(tbxFalta.Text);

            MessageBox.Show($"nome = {horista.NomeEmpregado} \n Matricula = {horista.Matricula} " +
                $"\n tempo de trabalho = {horista.TempoTrabalho()} dias \n Salario final = {horista.SalarioBruto().ToString("N2")}");

        }
    }
}
