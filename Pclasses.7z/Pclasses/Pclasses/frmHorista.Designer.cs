﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInsMen = new Button();
            tbxHora = new TextBox();
            tbxSal = new TextBox();
            tbxNome = new TextBox();
            tbxMat = new TextBox();
            lblEntra = new Label();
            lblSalMen = new Label();
            lblNome = new Label();
            lblMatricula = new Label();
            tbxDataEntrada = new TextBox();
            label1 = new Label();
            tbxFalta = new TextBox();
            lblFalta = new Label();
            SuspendLayout();
            // 
            // btnInsMen
            // 
            btnInsMen.Location = new Point(351, 313);
            btnInsMen.Name = "btnInsMen";
            btnInsMen.Size = new Size(116, 53);
            btnInsMen.TabIndex = 18;
            btnInsMen.Text = "Instanciar Horista";
            btnInsMen.UseVisualStyleBackColor = true;
            btnInsMen.Click += btnInsMen_Click;
            // 
            // tbxHora
            // 
            tbxHora.Location = new Point(351, 190);
            tbxHora.Name = "tbxHora";
            tbxHora.Size = new Size(125, 27);
            tbxHora.TabIndex = 17;
            // 
            // tbxSal
            // 
            tbxSal.Location = new Point(351, 157);
            tbxSal.Name = "tbxSal";
            tbxSal.Size = new Size(125, 27);
            tbxSal.TabIndex = 16;
            // 
            // tbxNome
            // 
            tbxNome.Location = new Point(351, 123);
            tbxNome.Name = "tbxNome";
            tbxNome.Size = new Size(125, 27);
            tbxNome.TabIndex = 15;
            // 
            // tbxMat
            // 
            tbxMat.Location = new Point(351, 90);
            tbxMat.Name = "tbxMat";
            tbxMat.Size = new Size(125, 27);
            tbxMat.TabIndex = 14;
            // 
            // lblEntra
            // 
            lblEntra.AutoSize = true;
            lblEntra.Location = new Point(181, 190);
            lblEntra.Name = "lblEntra";
            lblEntra.Size = new Size(42, 20);
            lblEntra.TabIndex = 13;
            lblEntra.Text = "Hora";
            // 
            // lblSalMen
            // 
            lblSalMen.AutoSize = true;
            lblSalMen.Location = new Point(181, 157);
            lblSalMen.Name = "lblSalMen";
            lblSalMen.Size = new Size(55, 20);
            lblSalMen.TabIndex = 12;
            lblSalMen.Text = "Salário";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(181, 123);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(50, 20);
            lblNome.TabIndex = 11;
            lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(181, 90);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(71, 20);
            lblMatricula.TabIndex = 10;
            lblMatricula.Text = "Matricula";
            // 
            // tbxDataEntrada
            // 
            tbxDataEntrada.Location = new Point(351, 226);
            tbxDataEntrada.Name = "tbxDataEntrada";
            tbxDataEntrada.Size = new Size(125, 27);
            tbxDataEntrada.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(181, 226);
            label1.Name = "label1";
            label1.Size = new Size(141, 20);
            label1.TabIndex = 20;
            label1.Text = "Entrada na Empresa";
            // 
            // tbxFalta
            // 
            tbxFalta.Location = new Point(351, 263);
            tbxFalta.Name = "tbxFalta";
            tbxFalta.Size = new Size(125, 27);
            tbxFalta.TabIndex = 23;
            // 
            // lblFalta
            // 
            lblFalta.AutoSize = true;
            lblFalta.Location = new Point(181, 263);
            lblFalta.Name = "lblFalta";
            lblFalta.Size = new Size(40, 20);
            lblFalta.TabIndex = 22;
            lblFalta.Text = "Falta";
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tbxFalta);
            Controls.Add(lblFalta);
            Controls.Add(tbxDataEntrada);
            Controls.Add(label1);
            Controls.Add(btnInsMen);
            Controls.Add(tbxHora);
            Controls.Add(tbxSal);
            Controls.Add(tbxNome);
            Controls.Add(tbxMat);
            Controls.Add(lblEntra);
            Controls.Add(lblSalMen);
            Controls.Add(lblNome);
            Controls.Add(lblMatricula);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnInsMen;
        private TextBox tbxHora;
        private TextBox tbxSal;
        private TextBox tbxNome;
        private TextBox tbxMat;
        private Label lblEntra;
        private Label lblSalMen;
        private Label lblNome;
        private Label lblMatricula;
        private TextBox tbxDataEntrada;
        private Label label1;
        private TextBox tbxFalta;
        private Label lblFalta;
    }
}