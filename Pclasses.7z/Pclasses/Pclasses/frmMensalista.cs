﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInsMen_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = tbxNome.Text;
            objMensalista.Matricula = Convert.ToInt32(tbxMat.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(tbxEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(tbxSalMen.Text);

            MessageBox.Show($"nome = {objMensalista.NomeEmpregado} \n Matricula = {objMensalista.Matricula} " +
                $"\n tempo de trabalho = {objMensalista.TempoTrabalho()} dias \n Salario final = {objMensalista.SalarioBruto().ToString("N2")}");
            MessageBox.Show($"empresa: {Mensalista.empresa}");
        }

        private void btnInstParamet_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista(Convert.ToInt32(tbxMat.Text), tbxNome.Text, Convert.ToDateTime(tbxEntrada.Text), Convert.ToDouble(tbxSalMen.Text));
            MessageBox.Show($"nome = {mensalista.NomeEmpregado} \n Matricula = {mensalista.Matricula} " +
            $"\n tempo de trabalho = {mensalista.TempoTrabalho()} dias \n Salario final = {mensalista.SalarioBruto().ToString("N2")}");

        }
    }
}
