﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            string aux = "";
            double media1 = 0;
            double media2 = 0;
            double mediaGeral = 0;

            for (int i = 0; i < 2; i++)
            {
                media1 = 0;
                media2 = 0;

                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota do aluno {i + 1} com o {j + 1}° professor", "Entrada de dados");
                    if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("nota invalida");
                        j--;
                    }
                    else
                    {
                        media1 += notas[0, j];
                        media2 += notas[1, j];
                    }
                }
                media1 /= 3;
                media2 /= 3;
                mediaGeral = (media1 + media2) / 2;
            }

            for (int i = 0; i < 2; i++) 
            {
                    lstbxAlu.Items.Add($"Aluno{i + 1}: nota Professor 1: {notas [i,0]}; nota Professor 2: " +
                        $"{notas[i, 1]}; Nota professor 3: {notas[i, 2]}; media: {(i != 1 ? media1.ToString("N2") : media2.ToString("N2"))}");
            }
            lstbxAlu.Items.Add("");
            lstbxAlu.Items.Add("-------------------------------");
            lstbxAlu.Items.Add($"Media geral: {mediaGeral.ToString("N2")}");
            lstbxAlu.Items.Add("");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxAlu.Items.Clear();
        }
    }
}
